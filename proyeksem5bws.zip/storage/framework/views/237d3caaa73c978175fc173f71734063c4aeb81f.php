<div class="container-news">
    <div class="container-pagination ">
        <div class="news-label">
            <h1>Al-Djaliel NEWS</h1>
        </div>
    </div>

    <div class="container-pagination ">
        <!-- Table structure here -->
        <table class="tablepaginitation" id="our-table">
            <div id="page-news">
                <script>
                    var newsData = [
                        <?php for ($i = 0; $i < 20; $i++) { ?> {
                                'judul': '<h1>Al-Djaliel adakan makan bareng santri satu minggu sekali</h1>',

                                'waktu': '<p><span>October</span> <span>01</span>,<span>2020</span></p>',

                                'gambar': '<img src="IMG/berita.JPG" alt="">',

                                'teks': '<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nihil ipsa quasi explicabo at, reiciendis, odio eum laudantium quaerat iste facilis iure tempore praesentium atque fugit delectus dicta impedit recusandae! Sint vero laudantium eveniet ducimus sit laborum quam voluptates aliquam similique sunt, ipsam, iusto impedit, ea modi recusandae eaque fuga reiciendis!</p>',

                                'selanjutnya': '<a href="berita.php">baca selanjutnya...</a>',
                            }
                        <?php } ?>
                    ]
                </script>
            </div>
        </table>
    </div>

    <div class="container-pagination ">
        <div id="pagination-wrapper"></div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\proyeksem5bws\resources\views/layouts/berita.blade.php ENDPATH**/ ?>