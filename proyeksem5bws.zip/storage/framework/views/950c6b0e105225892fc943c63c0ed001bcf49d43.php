<?php $__env->startSection('content'); ?>
<section class="section">

    <div class="section-header">
        <h1>Manejemen Berita</h1>
    </div>

    <div class="section-body">
        <div class="col-12 col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <form method="GET" class="form-inline">
                        <div class="form-group">
                            <input type="text" name="search" class="form-control" placeholder="Search" value="<?php echo e(request()->get('search')); ?>">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Search</button>
                        </div>
                    </form>
                    <a href="<?php echo e(route('berita.index')); ?>" class="pull-right">
                        <button type="button" class="btn btn-info">All Data</button>
                    </a>
                </div>
                <div class="card-header">
                    <a href="<?php echo e(route('berita.create')); ?>">
                        <button type="button" class="btn btn-primary">Tambah Data</button>
                    </a>
                </div>
                <div class="card-body" style="overflow: scroll">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Judul Berita</th>
                                <th scope="col">Foto</th>
                                <th scope="col">Kategori</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($berita->judul); ?></td>
                                <td><img src="<?php echo e(asset('foto/'. $berita->gambar)); ?>" width='75' height='75'></td>
                                <td><?php echo e($berita->relasiKategori->nama_kategori); ?></td>
                                <td>
                                    <a href="<?php echo e(route('berita.edit', ['id' => $berita->id])); ?>">
                                        <button type="button" class="btn btn-sm btn-info">Edit</button>
                                    </a>
                                    <a href="<?php echo e(route('berita.delete', ['id' => $berita->id])); ?>" onclick="return confirm('Delete data?');">
                                        <button type="button" class="btn btn-sm btn-danger">Hapus</button>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3">
                                    <center>Data kosong</center>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer text-right">
                    <nav class="d-inline-block">
                        <?php echo $data->appends(request()->except('page'))->render(); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyeksem5bws\resources\views/berita/index.blade.php ENDPATH**/ ?>