<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="img/png" href="<?php echo e(asset('assets_frontend/IMG/Logo.png')); ?>">
    <title>Al-Djaliel</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets_frontend/CSS/style.css')); ?>">
    <script src="<?php echo e(asset('assets_frontend/JS/pagination.js')); ?>"></script>
</head>

<body>
    <nav>
        <input type="checkbox" name="" id="ribbon">
        <ul>
            <li><a href="tentangpondok.php">Tentang Al-Djaliel</a></li>
            <li><a href="<?php echo e(route('frontend.pengurus.index')); ?>">Profil Pengurus</a></li>
            <li><a href="<?php echo e(route('frontend.registrasi.index')); ?>">Pendaftaran Santri Baru</a></li>
            <li><a href="<?php echo e(route('frontend.cekdata.index')); ?>">Cek Data Pendaftar</a></li>
            <li><a href="<?php echo e(route('frontend.home.index')); ?>">Halaman Utama</a></li>
        </ul>
        <label class="tie" for="ribbon"></label>
    </nav><?php /**PATH C:\xampp\htdocs\proyeksem5bws\resources\views/layouts/FrontendNavbar.blade.php ENDPATH**/ ?>