<?php $__env->startSection('content'); ?>
<section class="section">

    <div class="section-header">
        <h1>Kategori</h1>
    </div>

    <div class="section-body">
        <div class="col-12 col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <form method="GET" class="form-inline">
                        <div class="form-group">
                            <input type="text" name="search" class="form-control" placeholder="Search" value="<?php echo e(request()->get('search')); ?>">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Search</button>
                        </div>
                    </form>
                    <a href="<?php echo e(route('pembayaran.index')); ?>" class="pull-right">
                        <button type="button" class="btn btn-info">All Data</button>
                    </a>
                </div>
                <div class="card-header">

                </div>
                <div class="card-body" style="overflow: scroll">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">No Invoice</th>
                                <th scope="col">Total Pembayaran</th>
                                <th scope="col">Bukti Pembayaran</th>
                                <th scope="col">Scan Ijazah</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembayaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($pembayaran->no_invoice); ?></td>
                                <td><?php echo e($pembayaran->total_pembayaran); ?></td>
                                <td class="gambartabel"><img  src="<?php echo e(asset('buktipembayaran/'. $pembayaran->bukti_pembayaran)); ?>" width='75' height='75'></td>
                                <td class="gambartabel"><img  src="<?php echo e(asset('scn_ijz/'. $pembayaran->registrasi->file_ijazah)); ?>" width='75' height='75'></td>
                                <td><?php echo e($pembayaran->status); ?></td>
                                <td>
                                    <a href="">
                                        <button type="button" class="btn btn-sm btn-info">Detail</button>
                                    </a>
                                    <?php if($pembayaran->status == 'Pending'): ?>
                                    <a href="<?php echo e(route('pembayaran.proses', ['no_invoice' => $pembayaran->no_invoice])); ?>" onclick="return confirm('Proses Pendaftaran?');">
                                        <button type="button" class="btn btn-sm btn-info">Proses</button>
                                    </a>
                                    <?php endif; ?>
                                    <?php if($pembayaran->status == 'Proses'): ?>
                                    <a href="<?php echo e(route('pembayaran.verifikasi', ['nisn' => $pembayaran->nisn])); ?>" onclick="return confirm('Apakah Data akan di Verifikasi? Pastikan Berkas sudah benar');">
                                        <button type="button" class="btn btn-sm btn-info">Verifikasi</button>
                                    </a>
                                    <?php endif; ?>
                                    <?php if($pembayaran->status == 'Pending'): ?>
                                    <a href="<?php echo e(route('pembayaran.tolak', ['no_invoice' => $pembayaran->no_invoice])); ?>" onclick="return confirm('Yakin Pendaftaran akan di Tolak?');">
                                        <button type="button" class="btn btn-sm btn-danger">Tolak</button>
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3">
                                    <center>Data kosong</center>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer text-right">
                    <nav class="d-inline-block">
                        <?php echo $data->appends(request()->except('page'))->render(); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>

</section>
<!-- <div id="popupbuktibayar">
    <div class="popupcontent">
        <a class="tutup" href="#">close</a>
        <img src="<?php echo e(asset('buktipembayaran/'. $pembayaran->bukti_pembayaran)); ?>" width='' height=''>
    </div>
</div>

<div id="popupscanijazah">
    <div class="popupcontent">
        <a class="tutup" href="#">close</a>
        <img src="<?php echo e(asset('scn_ijz/'. $pembayaran->registrasi->file_ijazah)); ?>" width='75' height='75'>
    </div>
</div> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyeksem5bws\resources\views/pembayaran/index.blade.php ENDPATH**/ ?>