<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="img/png" href="<?php echo e(asset('assets_frontend/IMG/Logo.png')); ?>">
    <title>Al-Djaliel</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets_frontend/CSS/style.css')); ?>">
    <script src="<?php echo e(asset('assets_frontend/JS/pagination.js')); ?>"></script>
</head>

<?php echo $__env->make('layouts.FrontendNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="bg-registrasi2">
    <!-- Navbar -->
    <!-- Navbar End -->
    <form action="" class="registrasi2">
        <div class="form-group2">
            <input id="nisn" name="nisn" type="text" placeholder="Masukan No NISN Anda">
            <a href="#popup2" onclick="LoadData()" class="button green" target="">Cek Data Pendaftaran</a>
            <a href="<?php echo e(route('frontend.registrasi.index')); ?>" class="button blue">Belum Daftar</a>
        </div>
    </form>


    <form action="" id="popup">
        <div class="popup-bg">
            <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
            <h1>Data dan Berkas Dalam Proses Pengecekan <br> Silahkan Cek Kembali dalam 1 x 24 Jam</h1>
            <a href="#" class="btn-popup red">Tutup</a>
        </div>
    </form>


    <form id="popup2" action="<?php echo e(route('frontend.cekdata.submit')); ?>" enctype="multipart/form-data" method="POST">
        <div class="popup-bg">
            <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
            <h1>Data dan Berkas Dalam Proses Pengecekan <br> Silahkan Cek Kembali dalam 1 x 24 Jam</h1>
            <a href="#" class="btn-popup red">Tutup</a>
        </div>
    </form>


    <script src="<?php echo e(asset('/js/jquery-3.5.1.min.js')); ?>"></script>
    <script>
        function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;

            window.print();

            document.body.innerHTML = originalContents;
        }
    </script>
    <script type="text/javascript">
        function LoadData() {
            var nisn = $('#nisn').val();
            $.ajax({
                url: "<?php echo e(url('cekdata/form')); ?>/" + nisn,
                type: "GET",
                success: function(data) {
                    $('#popup2').html(data);
                }
            });
        }
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\proyeksem5bws\resources\views/frontend/cekdata/index.blade.php ENDPATH**/ ?>