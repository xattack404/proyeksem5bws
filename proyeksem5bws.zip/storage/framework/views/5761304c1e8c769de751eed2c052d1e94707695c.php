<?php $__env->startSection('content'); ?>
<section class="section">

  <div class="section-header">
    <h1>Pengurus</h1>
  </div>

  <div class="section-body">
    <div class="col-12 col-md-12 col-lg-12">
      <div class="card">
        <div class="card-header">
          <form method="GET" class="form-inline">
            <div class="form-group">
              <input type="text" name="search" class="form-control" placeholder="Search" value="<?php echo e(request()->get('search')); ?>">
            </div>
            <div class="form-group">
              <button type="submit" class="btn btn-primary">Search</button>
            </div>
          </form>
          <a href="<?php echo e(route('pengurus.index')); ?>" class="pull-right">
            <button type="button" class="btn btn-info">All Data</button>
          </a>
        </div>
        <div class="card-header">
          <a href="<?php echo e(route('pengurus.create')); ?>">
            <button type="button" class="btn btn-primary">Tambah Data</button>
          </a>
        </div>
        <div class="card-body" style="overflow: scroll">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col">Nama Pengurus</th>
                <th scope="col">Tempat Lahir</th>
                <th scope="col">Tanggal Lahir</th>
                <th scope="col">Pendidikan Terakhir</th>
                <th scope="col">Deskripsi</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengurus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($pengurus->nama_pengurus); ?></td>
                <td><?php echo e($pengurus->tempat_lahir); ?></td>
                <td><?php echo e($pengurus->tgl_lahir); ?></td>
                <td><?php echo e($pengurus->pendidikan_terakhir); ?></td>
                <td><?php echo e($pengurus->deskripsi); ?></td>
                <td>
                  <a href="<?php echo e(route('pengurus.edit', ['id' => $pengurus->id])); ?>">
                    <button type="button" class="btn btn-sm btn-info">Edit</button>
                  </a>
                  <a href="<?php echo e(route('pengurus.delete', ['id' => $pengurus->id])); ?>" onclick="return confirm('Delete data?');">
                    <button type="button" class="btn btn-sm btn-danger">Hapus</button>
                  </a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="3">
                  <center>Data kosong</center>
                </td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
        <div class="card-footer text-right">
          <nav class="d-inline-block">
            <?php echo $data->appends(request()->except('page'))->render(); ?>

          </nav>
        </div>
      </div>
    </div>
  </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyeksem5bws\resources\views/pengurus/index.blade.php ENDPATH**/ ?>