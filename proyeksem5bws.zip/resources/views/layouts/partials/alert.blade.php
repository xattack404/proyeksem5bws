@if (session('succes'))
<div class="alert">
    {{session ('succes')}}
</div>
@endif